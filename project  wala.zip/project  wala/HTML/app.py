from flask import Flask, request, jsonify, render_template, send_from_directory # type: ignore
from flask_cors import CORS # type: ignore
import pandas as pd # type: ignore
import numpy as np # type: ignore
from sklearn.neighbors import NearestNeighbors # type: ignore
import json
import os

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

# Load the dataset
df = pd.read_csv("doctor.csv")

# Convert symptoms string to list for easier searching
df['Symptoms'] = df['Symptoms'].str.lower().str.split(',')

def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculate the distance between two points using Haversine formula"""
    R = 6371  # Earth's radius in kilometers

    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    c = 2 * np.arcsin(np.sqrt(a))
    
    return R * c

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/doctors', methods=['POST'])
def find_doctors():
    try:
        data = request.get_json()
        user_lat = float(data['latitude'])
        user_lon = float(data['longitude'])
        user_symptoms = [s.strip().lower() for s in data['symptoms'].split(',')]

        # Filter doctors based on symptoms
        matching_doctors = []
        for _, doctor in df.iterrows():
            if any(symptom in doctor['Symptoms'] for symptom in user_symptoms):
                distance = calculate_distance(user_lat, user_lon, 
                                          doctor['Latitude'], doctor['Longitude'])
                doctor_info = {
                    'name': doctor['Doctor Name'],
                    'specialization': doctor['Specialization'],
                    'clinic': doctor['Clinic/Hospital'],
                    'contact': str(doctor['Contact']),  # Convert to string to handle long integers
                    'workingHours': doctor['Working Hours'],
                    'ratings': float(doctor['Ratings']),
                    'distance': round(distance, 2),
                    'expertise': doctor['Disease Expertise']
                }
                matching_doctors.append(doctor_info)

        # Sort by distance and get top 5
        matching_doctors.sort(key=lambda x: x['distance'])
        top_doctors = matching_doctors[:5]

        return jsonify({
            'success': True,
            'doctors': top_doctors
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@app.route('/api/specializations', methods=['GET'])
def get_specializations():
    """Get list of all specializations"""
    specializations = df['Specialization'].unique().tolist()
    return jsonify({
        'success': True,
        'specializations': specializations
    })

@app.route('/api/symptoms', methods=['GET'])
def get_symptoms():
    """Get list of all symptoms"""
    all_symptoms = []
    for symptoms_list in df['Symptoms']:
        all_symptoms.extend(symptoms_list)
    unique_symptoms = sorted(list(set(all_symptoms)))
    return jsonify({
        'success': True,
        'symptoms': unique_symptoms
    })

if __name__ == '__main__':
    # Create directories if they don't exist
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    app.run(debug=True, port=5000)